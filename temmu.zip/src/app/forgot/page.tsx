export default function forgot() {
  return (
    <h1 className="text-white">
      Sorry! This feature is still a work in progress!
    </h1>
  );
}
