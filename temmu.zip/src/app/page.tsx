"use client";

import {
  Button,
  Tab,
  TabGroup,
  TabList,
  TabPanel,
  TabPanels,
  Menu,
  MenuButton,
  MenuItem,
  MenuItems,
  Input,
  Field,
  Fieldset,
  Select,
} from "@headlessui/react";
import { User, Send, Plus, University, ChevronDown } from "lucide-react";
import CheckForCookies from "./components/checkforcookies";
import { Fragment, useEffect, useState } from "react";
import ImageWithFallback from "./components/image_with_fallback";
import { supabase } from "../lib/supabase";
import ProfileCard from "./components/profile_card";
import LoadImage from "../lib/LoadImage";
import { profile } from "console";

interface workspaceContentFormat {
  label: string;
  href: string;
  lastModified: string;
  AccessType: string;
  Collaborators: number;
}

interface userDataFormat {
  client_id: number;
  client_name: string;
  client_email: string;
  client_password: string;
  client_type: string;
  profile_picture: string;
  university: string;
}

interface menteeDataFormat {
  mentee: number;
  enrolled: boolean;
  mentee_name: string;
  mentee_email: string;
  mentee_university: string;
}

interface mentorDataFormat {
  mentor_list_id: number;
  mentor: number;
  mentee: number;
  enrolled: boolean;
  mentor_name?: string;
}

interface ForumsCommentFormat {
  comment_id: number;
  commenter_id: number;
  discussion_id: number;
  comment_text: string;
  comment_date: string;
  user: string;
}

interface ForumDiscussion {
  id: number;
  title: string;
  author: string;
  topic: string;
  preview: string;
  replies: number;
  time: string;
  recentComments: ForumsCommentFormat[];
  views: number;
}

interface mentorReturnFormat {
  mentor_id: string;
  count: string;
  mentor_name: string;
  profile_picture: string;
  university: string;
}

interface recommendedMentors {
  id: string;
  mentor_id: string;
  name: string;
  profile_picture: string;
  university: string;
  contribution: number;
}

const chatSeed = [
  {
    id: "mentor1",
    name: "Mentor One",
    avatar: "/avatars/mentor1.png",
    lastMessage: "Don't forget to submit your report!",
    status: "2 hours ago",
    unread: 0,
    messages: [
      {
        from: "them",
        content: "Hello! How can I assist you today?",
        timestamp: "10:00 AM",
      },
      {
        from: "you",
        content: "I need help with my project.",
        timestamp: "10:05 AM",
      },
      {
        from: "them",
        content: "Sure! What part are you struggling with?",
        timestamp: "10:10 AM",
      },
    ],
  },
  {
    id: "mentor2",
    name: "Mentor Two",
    avatar: "/avatars/mentor2.png",
    lastMessage: "Great job on the presentation!",
    status: "Typing...",
    unread: 5,
    messages: [
      {
        from: "them",
        content: "Hi! Ready for our session?",
        timestamp: "Yesterday 2:00 PM",
      },
      {
        from: "you",
        content: "Yes, looking forward to it!",
        timestamp: "Yesterday 2:05 PM",
      },
    ],
  },
];

// Topic color mapping
const topicColors: { [key: string]: string } = {
  "STEM Research": "bg-blue-400",
  "Project Ideas": "bg-green-400",
  "Mentorship Tips": "bg-purple-400",
  "General Discussion": "bg-yellow-400",
};

const AccessTypesColors: { [key: string]: string } = {
  Public: "bg-green-400",
  Private: "bg-red-400",
};
function Dashboard() {
  const [isCreating, setIsCreating] = useState(false);
  const [isManaging, setIsManaging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [chatSessions, setChatSessions] = useState(chatSeed);
  const [activeChatId, setActiveChatId] = useState(chatSeed[0]?.id ?? "");
  const [messageInput, setMessageInput] = useState("");
  const [workspaces, setWorkspaces] = useState<workspaceContentFormat[]>([]);
  const [WorkspaceName, setWorkspaceName] = useState("");
  const [WorkspaceAccessType, setWorkspaceAccessType] = useState("public");

  // later for chats
  const [userData, setUserData] = useState<userDataFormat>();
  const [showCreate, setShowCreate] = useState(false);
  const [menteeList, setMenteeList] = useState<menteeDataFormat[]>([]);
  const [mentorList, setMentorList] = useState<mentorDataFormat[]>([]);
  const [forums, setForums] = useState<ForumDiscussion[]>([]);
  const [commentInputs, setCommentInputs] = useState<{ [key: number]: string }>(
    {}
  );
  const [forumTitle, setTitle] = useState<string>("");
  const [forumTag, setForumTags] = useState<string>("STEM Research");
  const [forumDesc, setForumDesc] = useState<string>("");
  const [activeForumFilter, setActiveForumFilter] =
    useState<string>("All Topics");
  const [forumCount, setForumCount] = useState<number>(0);
  const [forumError, setForumError] = useState<string>("");
  const [recommendedMentors, setRecommendedMentors] = useState<
    recommendedMentors[]
  >([]);
  const activeChat = chatSessions.find((chat) => chat.id === activeChatId);
  const nowTime = new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  const handleSelectChat = (id: string) => {
    setActiveChatId(id);
    setChatSessions((prev) =>
      prev.map((chat) =>
        chat.id === id ? { ...chat, unread: 0, lastActive: "Just now" } : chat
      )
    );
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      console.log("File selected:", file.name);
      setSelectedFile(file);
      // Here you would typically handle the file upload to the server
    }
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() || !activeChat) return;
    const text = messageInput.trim();
    const ts = nowTime;
    setChatSessions((prev) =>
      prev.map((chat) =>
        chat.id === activeChat.id
          ? {
              ...chat,
              unread: 0,
              lastMessage: text,
              messages: [
                ...chat.messages,
                { from: "you", content: text, timestamp: ts },
              ],
            }
          : chat
      )
    );
    setMessageInput("");
  };

  async function fetchMentors() {
    const id = localStorage.getItem("User");
    console.log(id);
    const { data, error } = await supabase.rpc("top_mentors", { user_id: id });

    if (data && data.length > 0 && id) {
      const tempArr: recommendedMentors[] = [];
      data.map((m: mentorReturnFormat) => {
        const url = LoadImage(m.profile_picture);
        const mentor: recommendedMentors = {
          id: id,
          mentor_id: m.mentor_id,
          name: m.mentor_name,
          profile_picture: url,
          university: m.university,
          contribution: Number(m.count),
        };
        tempArr.push(mentor);
      });
      setRecommendedMentors(tempArr);
    }
    console.log(data, error);
  }

  async function fetchManageMentors(studentID: string) {
    try {
      const { data: mentorRows, error: mentorRowsError } = await supabase
        .from("MenteeList")
        .select("mentee_list_id, mentor, mentee, enrolled")
        .eq("mentee", Number(studentID))
        .limit(100);

      if (mentorRowsError) {
        console.error("fetchMentors - MentorList error:", mentorRowsError);
        setMentorList([]);
        return;
      }

      if (!mentorRows || mentorRows.length === 0) {
        setMentorList([]);
        return;
      }

      const mentorIds = Array.from(
        new Set(mentorRows.map((r: any) => r.mentor).filter(Boolean))
      );

      const { data: clients, error: clientsError } = await supabase
        .from("Clients")
        .select("client_id, client_name")
        .in("client_id", mentorIds);

      if (clientsError) {
        console.error("fetchMentors - Clients error:", clientsError);
      }

      const clientNameById: Record<number, string> = {};
      if (clients && clients.length > 0) {
        clients.forEach((c: any) => {
          clientNameById[c.client_id] = c.client_name;
        });
      }

      const mentors: mentorDataFormat[] = mentorRows.map((m: any) => ({
        mentor_list_id: m.mentor_list_id,
        mentor: m.mentor,
        mentee: m.mentee,
        enrolled: m.enrolled,
        mentor_name: clientNameById[m.mentor] ?? "Unknown",
      }));

      console.log("Fetched mentors:", mentors);

      setMentorList(mentors);
    } catch (error) {
      console.error("fetchMentors unexpected error:", error);
      setMentorList([]);
    }
  }

  async function fetchDiscussions(topicFilter: string = "All Topics") {
    let forumArray: any[] = [];
    let query = supabase
      .from("Discussions")
      .select(
        "*, DiscussionComments(*, Clients(client_name)), Clients!inner(client_name)"
      )
      .limit(10);
    console.log("hi");
    if (topicFilter !== "All Topics") {
      query = query.eq("tag", topicFilter);
    }

    const { data, error } = await query;

    if (error) {
      console.log(error);
    }

    if (data) {
      forumArray = data.map((f) => {
        const d = new Date(f.creation_date).toDateString();

        const comments: ForumsCommentFormat[] = f.DiscussionComments
          ? f.DiscussionComments.map((c: any) => ({
              comment_id: c.comment_id,
              commenter_id: c.commenter_id,
              discussion_id: c.discussion_id,
              comment_text: c.comment_text,
              comment_date: c.comment_date,
              user: c.Clients?.client_name || "Unknown",
            }))
          : [];

        return {
          id: f.discussion_id,
          title: f.title,
          author: f.Clients.client_name,
          topic: f.tag,
          preview: f.description,
          replies: comments.length,
          time: d,
          recentComments: comments,
          views: f.views || 0,
        };
      });

      setForums(forumArray);
      setForumCount(data.length);
    }
  }

  async function removeMentees(id: number) {
    const { data, error } = await supabase
      .from("MenteeList")
      .delete()
      .eq("mentee", id);

    setMenteeList((prev) => prev.filter((m) => m.mentee !== id));
  }

  async function enrollMentee(id: number) {
    const { data, error } = await supabase
      .from("MenteeList")
      .update({ enrolled: true })
      .eq("mentee", id);

    setMenteeList((prev) =>
      prev.map((m) => (m.mentee === id ? { ...m, enrolled: true } : m))
    );
  }

  useEffect(() => {
    const user_data = localStorage.getItem("User");
    async function fetchUserWorkspaces() {
      if (!user_data || user_data === "undefined") return;

      const { data: memberData, error: memberError } = await supabase
        .from("WorkspaceMembers")
        .select(
          `
      Workspace!inner(
        workspace_id,
        creation_date,
        is_private,
        workspace_name,
        WorkspaceMembers!inner(member_id)
      )
    `
        )
        .eq("member_id", user_data);

      if (memberError) {
        console.error(memberError);
        setWorkspaces([]);
        return;
      }

      if (!memberData || memberData.length === 0) {
        setWorkspaces([]);
        return;
      }

      const workspaceArray: workspaceContentFormat[] = memberData
        .map((member) => {
          const workspaces = Array.isArray(member.Workspace)
            ? member.Workspace
            : [member.Workspace];

          return workspaces.map((ws) => ({
            label: ws.workspace_name,
            href: `/workspace/${ws.workspace_id}`,
            lastModified: new Date(ws.creation_date).toDateString(),
            AccessType: ws.is_private ? "Private" : "Public",
            Collaborators: ws.WorkspaceMembers?.length ?? 0,
          }));
        })
        .flat();

      setWorkspaces(workspaceArray);
    }

    async function fetchMentees(mentorID: string) {
      const { data, error } = await supabase
        .from("MenteeList")
        .select(
          `mentee, enrolled, Mentee:Clients!mentee(client_name, client_email, university)`
        )
        .eq("mentor", mentorID);

      if (data && data.length > 0) {
        const menteeArr = data.flatMap((m) => {
          const mentees = Array.isArray(m.Mentee) ? m.Mentee : [m.Mentee];

          return mentees.map((mentee) => ({
            mentee: m.mentee,
            enrolled: m.enrolled,
            mentee_name: mentee?.client_name ?? "",
            mentee_email: mentee?.client_email ?? "",
            mentee_university: mentee?.university ?? "",
          }));
        });

        setMenteeList(menteeArr);
      } else {
        if (error) {
          console.log(error);
        } else {
          setMenteeList([]);
        }
      }
    }

    async function fetchUserData() {
      const userInformation = localStorage.getItem("UserData");
      if (
        userInformation &&
        userInformation !== "undefined" &&
        userInformation !== "null"
      ) {
        try {
          return JSON.parse(userInformation);
        } catch (e) {
          console.error("Error parsing UserData", e);
          return null;
        }
      } else {
        if (!user_data || user_data === "undefined") return null;
        try {
          const res = await fetch(`/api/data_fetch/${user_data}`);
          if (!res.ok) return null;
          const data = await res.json();
          localStorage.setItem("UserData", JSON.stringify(data));
          return data;
        } catch (error) {
          console.error(error);
          return null;
        }
      }
    }

    async function fetchAll() {
      const userInfo = await fetchUserData();
      setUserData(userInfo);
      fetchUserWorkspaces();
      if (userInfo.client_type == "Mentor") {
        if (user_data) {
          fetchMentees(user_data);
        }
      } else if (userInfo.client_type == "Student") {
        if (user_data) {
          fetchManageMentors(user_data);
          fetchMentors();
        }
      }
      fetchDiscussions();
    }

    // socket.current = new WebSocket("ws://localhost:3000/api/chat_server");

    fetchAll();
  }, []);

  async function postForums() {
    setForumError("");
    const user_id = localStorage.getItem("User");
    const now = new Date();

    if (forumTitle == "") {
      console.log("Missing title. Please add one.");
      setForumError("Missing title. Please add one.");
      return null;
    }

    const { data, error } = await supabase
      .from("Discussions")
      .insert({
        poster_id: user_id,
        title: forumTitle,
        description: forumDesc,
        tag: forumTag,
        creation_date: now.toISOString(),
      })
      .select();

    if (error) {
      console.log(error);
      setForumError("Error posting forum. Please try again.");
    }

    if (forumCount < 10) {
      const stored = localStorage.getItem("UserData");
      if (stored) {
        const user_data = JSON.parse(stored);
        if (user_data) {
          const user_name = user_data.client_name;

          // Use the inserted row's discussion_id if available, otherwise fall back to a timestamp-based id
          const newId =
            data && data.length > 0 ? data[0].discussion_id : Date.now();

          const fd: ForumDiscussion = {
            id: newId,
            title: forumTitle,
            author: user_name,
            topic: forumTag,
            preview: forumDesc,
            replies: 0,
            time: now.toISOString(),
            recentComments: [],
            views: 0,
          };

          setForums((prev) => [...prev, fd]);
        }
      }
    }

    setShowCreate(false);
  }

  async function submitForumComment(discussionId: number, commentText: string) {
    // Add this new function
    const user_id = localStorage.getItem("User");
    const text = commentText.trim();
    const now = new Date();
    if (!text) return;
    const { data, error } = await supabase
      .from("DiscussionComments")
      .insert({
        commenter_id: user_id,
        discussion_id: discussionId,
        comment_text: text,
        comment_date: now.toISOString(),
      })
      .select();
    if (error) {
      console.error("Error submitting comment:", error);
      return;
    }

    if (data) {
      const newComment = data[0];
      const commentForState: ForumsCommentFormat = {
        comment_id: newComment.comment_id,
        commenter_id: newComment.commenter_id,
        discussion_id: newComment.discussion_id,
        comment_text: newComment.comment_text,
        comment_date: newComment.comment_date,
        user: userData ? userData.client_name : "Unknown",
      };
      setForums((prev) =>
        prev.map((f) => {
          if (f.id === discussionId) {
            return {
              ...f,
              recentComments: [...f.recentComments, commentForState],
              replies: f.replies + 1,
            };
          }
          return f;
        })
      );
      setCommentInputs((prev) => ({ ...prev, [discussionId]: "" }));
    }
  }

  async function RemoveMentors() {
    const user_id = localStorage.getItem("User");
    if (!user_id || user_id === "undefined") {
      alert("User not logged in.");
      return;
    }
    const { data, error } = await supabase
      .from("MenteeList")
      .delete()
      .eq("mentee", user_id);
    if (error) {
      console.error("Error removing mentors:", error);
      alert("Failed to remove mentors. Please try again.");
    } else {
      console.log("Mentors removed:", data);
      // Refresh mentor list
      setMentorList([]);
    }
  }

  async function createWorkspace() {
    const user_id = localStorage.getItem("User");
    const now = new Date();

    if (!WorkspaceName.trim()) {
      alert("Workspace name cannot be empty.");
      return;
    }

    if (!user_id || user_id === "undefined") {
      alert("User not logged in.");
      return;
    }

    const { data, error } = await supabase
      .from("Workspace")
      .insert({
        workspace_name: WorkspaceName,
        is_private: WorkspaceAccessType === "private",
        creation_date: now.toISOString(),
      })
      .select();

    console.log(data);

    if (error) {
      console.error("Error creating workspace:", error);
      alert("Failed to create workspace. Please try again.");
    } else {
      console.log("Workspace created:", data);
      if (data && data.length > 0) {
        const newWorkspaceId = data[0].workspace_id;
        const formattedNewWorkspace: workspaceContentFormat = {
          label: data[0].workspace_name,
          href: `/workspace/${data[0].workspace_id}`,
          lastModified: new Date(data[0].creation_date).toDateString(),
          AccessType: data[0].is_private ? "Private" : "Public",
          Collaborators: 1,
        };

        setWorkspaces((prev) => [...prev, formattedNewWorkspace]);

        const { data: insertedMemberData, error: memberError } = await supabase
          .from("WorkspaceMembers")
          .insert({
            workspace_id: newWorkspaceId,
            member_id: user_id,
            member_type: "Owner",
          });

        console.log("Adding workspace member:", { insertedMemberData });

        if (memberError) {
          console.error("Error adding workspace member:", memberError);
          alert("Workspace created, but failed to add you as a member.");
        } else {
          console.log("Workspace member added.");
        }
      }

      setWorkspaceName(""); // Clear input
      setWorkspaceAccessType("public"); // Reset to default
      setIsCreating(false); // Close the creation form
    }
  }

  return (
    <div className="w-screen h-full">
      <CheckForCookies />
      <TabGroup className={"flex flex-col items-center mt-10 gap-10"}>
        <div className="flex flex-row justify-between items-center w-[90vw]">
          {/* left spacer */}
          <div className="hidden justify-between items-center w-[10vw]"></div>

          {/* center tabs */}
          <div className="flex flex-row content-between items-center gap-6">
            <TabList
              className={"flex gap-10 bg-(--foreground) rounded-4xl w-auto p-4"}
            >
              <Tab
                className={
                  "rounded-4xl p-2 data-hover:bg-(--hover) hover:cursor-pointer data-selected:bg-(--highlighted) data-selected:text-white data-seleceted:font-bold transition-[background-color,color] duration-300 ease-in-out"
                }
              >
                Workspace
              </Tab>
              <div className={"flex"}>
                {" "}
                {/* Roles Exclusives */}
                {userData?.client_type === "Student" && (
                  <Tab
                    className={
                      " flex rounded-4xl p-2 data-hover:bg-(--hover) hover:cursor-pointer data-selected:bg-(--highlighted) data-selected:text-white data-seleceted:font-bold transition-[background-color,color] duration-300 ease-in-out"
                    }
                  >
                    Find Mentors
                  </Tab>
                )}
                {userData?.client_type === "Mentor" && (
                  <Tab
                    className={
                      "rounded-4xl p-2 data-hover:bg-(--hover) hover:cursor-pointer data-selected:bg-(--highlighted) data-selected:text-white data-seleceted:font-bold transition-[background-color,color] duration-300 ease-in-out"
                    }
                  >
                    Manage Mentees
                  </Tab>
                )}
              </div>
              <Tab
                className={
                  "hidden rounded-4xl p-2 data-hover:bg-(--hover) hover:cursor-pointer data-selected:bg-(--highlighted) data-selected:text-white data-seleceted:font-bold transition-[background-color,color] duration-300 ease-in-out"
                }
                disabled
              >
                Chats
              </Tab>
              <Tab
                className={
                  "rounded-4xl p-2 data-hover:bg-(--hover) hover:cursor-pointer data-selected:bg-(--highlighted) data-selected:text-white data-seleceted:font-bold transition-[background-color,color] duration-300 ease-in-out"
                }
              >
                Forums
              </Tab>
            </TabList>
          </div>

          {/* User option */}
          <div className="flex justify-end w-1/8">
            <Menu>
              <MenuButton className="flex flex-row items-center gap-2 bg-(--foreground) rounded-4xl w-auto p-4 data-hover:bg-(--hover) data-selected:bg-(--highlighted) hover:cursor-pointer hover:text-white transition-[background-color,color] duration-300 ease-in-out">
                <User size={30} />
                <span>My account</span>
              </MenuButton>
              <MenuItems
                anchor="bottom end"
                transition
                className="bg-(--foreground) rounded-3xl p-2 flex flex-col gap-2 border-black border w-(--button-width) [--anchor-gap: 8px] origin-top transition duration-200 ease-out data-closed:scale-95 data-closed:opacity-0 z-100"
              >
                <MenuItem>
                  <a
                    className="block pl-2 data-focus:bg-(--hover) rounded-2xl p-1 transition duration-300 ease-in-out"
                    href="/profile"
                  >
                    My Profile
                  </a>
                </MenuItem>
                <MenuItem>
                  <a
                    className="block pl-2 data-focus:bg-(--hover) rounded-2xl p-1 transition duration-300 ease-in-out"
                    href="/logout"
                  >
                    Logout
                  </a>
                </MenuItem>
              </MenuItems>
            </Menu>
          </div>
        </div>
        <TabPanels as={Fragment}>
          <TabPanel
            className={
              "w-[90vw] h-[80vh] bg-(--foreground) rounded-4xl overflow-y-auto bg-clip-content"
            }
          >
            <div
              className={`${
                isCreating ? "hidden" : "flex"
              } flex-col h-full w-full p-6`}
            >
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Your Workspaces</h1>
                <Button
                  onClick={() => setIsCreating(true)}
                  className="bg-blue-400 text-black px-4 py-2 rounded-4xl hover:cursor-pointer hover:scale-115 hover:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out"
                >
                  Create New Workspace
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {workspaces.map((workspace) => (
                  <div
                    key={workspace.href}
                    className="bg-(--bg-section) rounded-3xl p-6 border-2 border-gray-500 shadow-lg hover:shadow-2xl hover:scale-105 transition-all duration-300 ease-in-out"
                  >
                    <h3 className="text-xl font-bold mb-3">
                      {workspace.label}
                    </h3>
                    <div className="flex flex-col gap-3">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <span>Created on: {workspace.lastModified}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span
                          className={`${
                            AccessTypesColors[workspace.AccessType]
                          } text-black px-2 py-1 rounded-lg text-xs font-medium`}
                        >
                          {workspace.AccessType}
                        </span>
                        <span className="text-gray-600">
                          {workspace.Collaborators} collaborators
                        </span>
                      </div>
                      <div className="border-t border-gray-600 pt-3 mt-2">
                        <a
                          href={workspace.href}
                          className="block w-full bg-blue-400 text-black text-center px-4 py-2 rounded-2xl hover:bg-(--highlighted) hover:text-white hover:scale-105 transition-all duration-300 ease-in-out font-medium"
                        >
                          Open Workspace
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div
              className={`${
                isCreating ? "flex" : "hidden"
              } flex-col justify-center w-full h-[60vh] mt-10 items-center`}
            >
              <Fieldset className="mt-6 w-[60%]">
                <legend className="text-lg font-bold mb-4">
                  New Workspace
                </legend>
                <Field className="mb-4">
                  <label
                    htmlFor="workspace_name"
                    className="block text-sm font-medium mb-2"
                  >
                    Workspace Name
                  </label>
                  <Input
                    id="workspace_name"
                    name="workspace_name"
                    type="text"
                    value={WorkspaceName}
                    onChange={(e) => setWorkspaceName(e.target.value)}
                    className={
                      "w-full bg-(--bg-section) border-2 border-gray-500 rounded-lg p-2 focus:border-blue-400 transition-colors"
                    }
                  />
                </Field>
                <Field className="mb-4">
                  <label
                    htmlFor="is_private"
                    className="block text-sm font-medium mb-2"
                  >
                    Access Type
                  </label>
                  <Select
                    name="status"
                    aria-label="Access Type"
                    className="w-full bg-(--bg-section) rounded-lg p-2 border-2 border-gray-500 focus:border-blue-400 transition-colors"
                    value={WorkspaceAccessType}
                    onChange={(e) => setWorkspaceAccessType(e.target.value)}
                  >
                    <option value="public">Public</option>
                    <option value="private">Private</option>
                  </Select>
                </Field>
                <div className="mt-10 flex flex-row items-center justify-around gap-4">
                  <Button
                    onClick={() => createWorkspace()}
                    className={
                      "bg-blue-400 text-black px-4 py-2 rounded-4xl hover:cursor-pointer hover:scale-105 hover:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out"
                    }
                  >
                    Create Workspace
                  </Button>
                  <Button
                    onClick={() => setIsCreating(false)}
                    className={
                      "bg-red-400 text-black px-4 py-2 rounded-4xl hover:cursor-pointer hover:scale-105 hover:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out"
                    }
                  >
                    Cancel
                  </Button>
                </div>
              </Fieldset>
            </div>
          </TabPanel>

          {userData?.client_type === "Student" && (
            <TabPanel
              className={
                "flex w-[90vw] h-[80vh] bg-(--foreground) rounded-4xl p-4"
              }
            >
              {/* Find Mentors Container */}
              <div
                className={`${
                  isManaging ? "hidden" : "flex"
                } flex-col items-center w-full h-full p-20 overflow-y-auto`}
              >
                <h1 className="text-2xl mb-1 font-bold">Looking for Mentor?</h1>
                <span className="text-lg mb-4">Just Search!</span>
                <form className="flex flex-row gap-4">
                  <Input
                    name="full_name"
                    type="text"
                    className={"bg-blue-400 rounded-lg p-2 text-black"}
                    placeholder="Type the name!"
                  ></Input>
                  <Button
                    className={
                      "bg-blue-400 rounded-lg p-2 text-black data-hover:bg-(--highlighted) data-hover:cursor-pointer data-hover:text-white transition duration-300 ease-in-out"
                    }
                  >
                    Search
                  </Button>
                </form>

                {/* Recommended Mentors Section */}
                <div className="flex flex-col items-center mt-4">
                  <h1>Here's some recommended tutors you may like!</h1>
                  <div className="grid grid-cols-3">
                    {recommendedMentors.map((m) => (
                      <div key={m.name} className="grid grid-cols-3 gap-4 p-4">
                        <ProfileCard
                          id={m.id}
                          mentor_id={m.mentor_id}
                          name={m.name}
                          profile_picture={m.profile_picture}
                          university={m.university}
                          contribution={m.contribution}
                        />
                      </div>
                    ))}
                  </div>

                  {/* Search Results */}
                  <div className=" hidden grid-cols-3 gap-4 mt-4">
                    <h1>Search Results for NAME INPUT</h1>
                    {/* Mentor cards would go here */}
                  </div>

                  {/* No Results Message */}
                  <div className="hidden mt-4">
                    <p>
                      No mentors found. Try searching with different keywords.
                    </p>
                  </div>
                </div>
              </div>

              <div
                className={`${
                  isManaging
                    ? "flex flex-col items-center justify-between p-2 w-full h-full"
                    : "hidden"
                }`}
              >
                <div className="flex flex-col items-center w-full max-h-[50%] p-4 mb-4 mt-10 overflow-y-auto">
                  <h1 className="text-2xl mb-1 font-bold">Manage Mentors</h1>
                  {mentorList.filter((m) => m.enrolled).length === 0 ? (
                    <span className="text-lg mb-4">
                      You have no mentors currently.
                    </span>
                  ) : (
                    <>
                      <span className="text-lg mb-4">
                        Here are your current mentors:
                      </span>
                      <div className="grid grid-cols-2 gap-4 w-[80%] max-h-[60%] overflow-y-auto">
                        {mentorList
                          .filter((m) => m.enrolled)
                          .map((m, idx) => (
                            <div
                              key={m.mentor_list_id ?? `mentor-${idx}`}
                              className="flex flex-row justify-between items-center p-4 bg-blue-300 rounded-lg shadow-lg"
                            >
                              <span>{m.mentor_name}</span>
                              <Button
                                onClick={() => RemoveMentors()}
                                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:cursor-pointer hover:scale-110 transition duration-200 ease-in-out"
                              >
                                Remove Mentors
                              </Button>
                            </div>
                          ))}
                      </div>
                    </>
                  )}
                </div>
                <div className="flex flex-col items-center w-full max-h-[50%] p-4 mb-10 overflow-y-auto">
                  <h1 className="text-2xl mb-1 font-bold">Pending Requests</h1>
                  {mentorList.filter((m) => !m.enrolled).length === 0 ? (
                    <span className="text-lg mb-4">
                      You have no pending mentor requests.
                    </span>
                  ) : (
                    <>
                      <span className="text-lg mb-4">
                        Here are your pending mentor requests:
                      </span>
                      <div className="grid grid-cols-2 gap-4 w-[80%] max-h-[60%] overflow-y-auto">
                        {mentorList
                          .filter((m) => !m.enrolled)
                          .map((m, idx) => (
                            <div
                              key={m.mentor_list_id ?? `pending-mentor-${idx}`}
                              className="flex flex-row justify-between items-center p-4 bg-blue-300 rounded-lg shadow-lg"
                            >
                              <span>{m.mentor_name}</span>
                              <div className="flex flex-row gap-2">
                                <Button
                                  onClick={() => RemoveMentors()}
                                  className="bg-red-500 text-white px-4 py-2 rounded-lg hover:cursor-pointer hover:scale-110 transition duration-200 ease-in-out"
                                >
                                  Cancel Request
                                </Button>
                              </div>
                            </div>
                          ))}
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div className="absolute top-45 right-30 z-50">
                <Button
                  onClick={() => setIsManaging(!isManaging)}
                  className="bg-blue-400 text-black px-4 py-2 rounded-4xl hover:cursor-pointer hover:scale-115 hover:bg-(--hover) data-active:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out"
                >
                  {isManaging ? "Done Managing" : "Manage Mentors"}
                </Button>
              </div>
            </TabPanel>
          )}

          {userData?.client_type === "Mentor" && (
            <TabPanel
              className={
                "flex flex-col justify-between items-center w-[90vw] h-[80vh] bg-(--foreground) rounded-4xl overflow-y-auto p-4"
              }
            >
              {" "}
              {/* Manage Mentees Container */}
              <div className="flex flex-col items-center w-full max-h-[60%] p-4 mb-4 overflow-y-auto">
                <h1 className="text-2xl mb-1 font-bold">Manage Your Mentees</h1>
                <span className="text-lg mb-4">
                  Here are your current mentees:
                </span>
                <div className="flex flex-col gap-4 w-[80%] max-h-[60%] overflow-y-auto">
                  {menteeList
                    .filter((m) => m.enrolled)
                    .map((m) => (
                      <div
                        key={m.mentee}
                        className="flex flex-row justify-between items-center p-4 bg-blue-300 rounded-lg shadow-lg"
                      >
                        <span>
                          {m.mentee_name} | {m.mentee_email} |{" "}
                          {m.mentee_university}
                        </span>
                        <Button
                          onClick={(e) => removeMentees(m.mentee)}
                          className="bg-red-500 text-white px-4 py-2 rounded-lg hover:cursor-pointer hover:font-bold"
                        >
                          Remove Mentee
                        </Button>
                      </div>
                    ))}
                </div>
              </div>
              <div className="mt-2 w-[80%] max-h-[60%] border-t border-gray-600">
                {menteeList.length > 0 ? (
                  <>
                    <h1 className="px-4 py-2 rounded-lg font-bold">Requests</h1>
                    <div className="flex flex-col gap-4 w-full h-[40%]">
                      {menteeList
                        .filter((m) => !m.enrolled)
                        .map((m) => (
                          <div
                            key={m.mentee}
                            className="flex flex-row justify-between items-center p-4 bg-blue-300 rounded-lg shadow-lg"
                          >
                            <span>
                              {m.mentee_name} | {m.mentee_email} |{" "}
                              {m.mentee_university}
                            </span>
                            <div className="flex flex-row gap-2">
                              <Button
                                onClick={(e) => enrollMentee(m.mentee)}
                                className="bg-green-500 text-white px-4 py-2 rounded-lg hover:cursor-pointer hover:font-bold"
                              >
                                Accept
                              </Button>
                              <Button
                                onClick={(e) => removeMentees(m.mentee)}
                                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:cursor-pointer hover:font-bold"
                              >
                                Decline
                              </Button>
                            </div>
                          </div>
                        ))}
                    </div>
                  </>
                ) : (
                  <>
                    <h1 className="px-4 py-2 rounded-lg font-bold">
                      No Requests
                    </h1>
                  </>
                )}
              </div>
            </TabPanel>
          )}

          <TabPanel
            className={"w-[90vw] h-[80vh] bg-(--foreground) rounded-4xl"}
          >
            <div className="flex flex-row justify-between items-center h-full">
              {" "}
              {/* Chats container */}
              <div className="flex flex-col justify-center align-center w-[45vw] h-full">
                {" "}
                <div className="flex flex-col flex-wrap gap-2 p-4 h-full">
                  {/* Chat Lists */}
                  <div className="flex flex-col align-top gap-4">
                    {chatSessions.map((chat) => (
                      <button
                        key={chat.id}
                        onClick={() => handleSelectChat(chat.id)}
                        className={`flex flex-row justify-between items-center p-2 ${
                          chat.id === activeChatId
                            ? "bg-(--highlighted)"
                            : "bg-(--bg-section)"
                        } rounded-lg shadow-lg hover:cursor-pointer hover:font-bold hover:bg-(--hover) transition duration-200 ease-in-out`}
                      >
                        <div className="flex flex-row justify-between items-center p-2 w-full">
                          <div className="flex flex-col text-left">
                            <span>{chat.name.slice(0, 20)}</span>
                            <span className="text-sm text-gray-600">
                              {chat.lastMessage ||
                                chat.messages.at(-1)?.content}{" "}
                            </span>
                          </div>
                          {chat.unread > 0 && (
                            <span className="self-start rounded-full bg-red-400 px-2 py-1 text-[11px] font-semibold text-black">
                              {chat.unread} unread chat
                            </span>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>

                  {/* No chats message */}
                  <div className="hidden flex-col items-center justify-center gap-4 mt-10">
                    <p>No chats available. Start a new chat!</p>
                  </div>
                </div>
              </div>
              <div className="border-l border-gray-600 h-[70vh] shadow-4xl"></div>
              <div className="flex flex-col items-center justify-center flex-wrap gap-2 p-4 w-[45vw] h-full overflow-y-auto">
                {/* Chat window would go here */}
                {activeChat ? (
                  <>
                    <div className="flex flex-col w-full h-full gap-4 overflow-y-auto mb-4">
                      <>
                        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-700">
                          <div className="flex items-center gap-3">
                            <ImageWithFallback
                              className="w-10 h-10 rounded-3xl"
                              src={activeChat.avatar}
                            ></ImageWithFallback>
                            <div className="flex flex-col">
                              <p className="font-semibold">{activeChat.name}</p>
                              <span className="text-xs text-gray-500">
                                {activeChat.status}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex-1 overflow-y-auto px-6 py-4 flex flex-col gap-3">
                          {activeChat.messages.map((msg, idx) => (
                            <div
                              key={idx}
                              className={`flex ${
                                msg.from === "you"
                                  ? "justify-end"
                                  : "justify-start"
                              }`}
                            >
                              <div
                                className={`max-w-[75%] rounded-3xl px-4 py-2 text-sm shadow transition ${
                                  msg.from === "you"
                                    ? "bg-yellow-400 text-black rounded-br-sm"
                                    : "bg-(--bg-section) text-gray-100 rounded-bl-sm"
                                }`}
                              >
                                <p>{msg.content}</p>
                                <span className="mt-1 block text-[11px] text-gray-700 text-right">
                                  {msg.timestamp}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="flex items-center gap-3 px-6 py-4 border-t border-gray-700">
                          <Menu>
                            <MenuButton className="flex h-11 w-11 items-center justify-center p-2 bg-(--bg-section) rounded-full hover:cursor-pointer hover:bg-(--hover) hover:scale-105 transition duration-300 ease-in-out">
                              <Plus size={16} />
                            </MenuButton>
                            <MenuItems
                              anchor="top start"
                              transition
                              className="bg-(--foreground) rounded-3xl p-2 flex flex-col gap-2 border-black border w-fit [--anchor-gap: 8px] origin-top transition duration-200 ease-out data-closed:scale-95 data-closed:opacity-0"
                            >
                              <MenuItem>
                                <label className="block w-full pl-2 data-focus:bg-(--hover) rounded-2xl p-1 transition duration-300 ease-in-out hover:cursor-pointer">
                                  <input
                                    type="file"
                                    accept="application/pdf,image/jpeg,image/png"
                                    onChange={handleFileChange}
                                    className="hidden"
                                  />
                                  Upload File
                                </label>
                              </MenuItem>
                              <MenuItem>
                                <Button
                                  className={
                                    "px-3 py-2 rounded-2xl hover:bg-(--hover) hover:cursor-pointer transition duration-300 ease-in-out"
                                  }
                                >
                                  Invite to workspace
                                </Button>
                              </MenuItem>
                            </MenuItems>
                          </Menu>
                          <Input
                            value={messageInput}
                            onChange={(e) => setMessageInput(e.target.value)}
                            onKeyDown={(e) =>
                              e.key === "Enter" &&
                              (e.preventDefault(), handleSendMessage())
                            }
                            placeholder="Send a chat..."
                            className="flex-1 bg-(--bg-section) rounded-full px-4 py-3 border-2 border-gray-600 focus:border-yellow-400 transition-colors"
                          />
                          <Button
                            onClick={handleSendMessage}
                            className="flex h-11 w-11 items-center justify-center rounded-full bg-yellow-400 text-black hover:scale-105 hover:bg-(--hover) hover:cursor-pointer hover:text-white transition"
                          >
                            <Send size={16} />
                          </Button>
                        </div>
                      </>
                    </div>
                  </>
                ) : (
                  <div className="hidden flex-col items-center justify-center gap-4 mb-10 h-full">
                    <p>Select a chat to start messaging.</p>
                  </div>
                )}
              </div>
            </div>
          </TabPanel>

          <TabPanel
            className={
              "w-[90vw] h-[80vh] bg-(--foreground) rounded-4xl bg-clip-content"
            }
          >
            <div
              className={`${
                showCreate ? "hidden" : "flex"
              } flex-col w-full h-full p-6`}
            >
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Forums</h1>
                <Button
                  onClick={() => setShowCreate(true)}
                  className="bg-blue-400 text-black px-4 py-2 rounded-4xl hover:cursor-pointer hover:scale-115 hover:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out"
                >
                  New Discussion
                </Button>
              </div>
              <div className="flex flex-row gap-4 mb-6">
                <Input
                  type="text"
                  placeholder="Search discussions..."
                  className="flex-1 bg-(--bg-section) rounded-lg px-4 py-2 border-2 border-gray-500 focus:border-blue-400 transition-colors"
                />
                <Button className="bg-blue-400 text-black px-4 py-2 rounded-4xl hover:cursor-pointer hover:scale-105 hover:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out">
                  Search
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mb-6">
                <button
                  onClick={() => {
                    setActiveForumFilter("All Topics");
                    fetchDiscussions("All Topics");
                  }}
                  className="bg-blue-400 text-black px-3 py-1 rounded-full text-sm font-medium hover:bg-(--hover) hover:scale-105 hover:cursor-pointer transition-all"
                >
                  All Topics
                </button>
                <button
                  onClick={() => {
                    setActiveForumFilter("STEM Research");
                    fetchDiscussions("STEM Research");
                  }}
                  className="bg-(--bg-section) text-white px-3 py-1 rounded-full text-sm font-medium hover:bg-blue-500 hover:scale-105 hover:cursor-pointer active:bg-blue-400 transition-all"
                >
                  STEM Research
                </button>
                <button
                  onClick={() => {
                    setActiveForumFilter("Project Ideas");
                    fetchDiscussions("Project Ideas");
                  }}
                  className="bg-(--bg-section) text-white px-3 py-1 rounded-full text-sm font-medium hover:bg-green-500 hover:scale-105 hover:cursor-pointer active:bg-green-400 transition-all"
                >
                  Project Ideas
                </button>
                <button
                  onClick={() => {
                    setActiveForumFilter("Mentorship Tips");
                    fetchDiscussions("Mentorship Tips");
                  }}
                  className="bg-(--bg-section) text-white px-3 py-1 rounded-full text-sm font-medium hover:bg-purple-500 hover:scale-105 hover:cursor-pointer active:bg-purple-400 transition-all"
                >
                  Mentorship Tips
                </button>
                <button
                  onClick={() => {
                    setActiveForumFilter("General Discussion");
                    fetchDiscussions("General Discussion");
                  }}
                  className="bg-(--bg-section) text-white px-3 py-1 rounded-full text-sm font-medium hover:bg-yellow-500 hover:scale-105 hover:cursor-pointer hover:text-black active:bg-yellow-400 active:text-black transition-all"
                >
                  General Discussion
                </button>
              </div>
              <div className="flex flex-col gap-4 overflow-y-auto">
                {forums.map((discussion, index) => (
                  <div
                    key={index}
                    className="bg-(--bg-section) rounded-2xl p-4 border-2 border-gray-500 hover:border-blue-400 hover:shadow-lg transition-all duration-300 hover:cursor-pointer"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-lg font-bold">{discussion.title}</h3>
                      <span
                        className={`${
                          topicColors[discussion.topic] || "bg-gray-600"
                        } text-black px-2 py-1 rounded-lg text-xs font-medium whitespace-nowrap ml-2`}
                      >
                        {discussion.topic}
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">
                      {discussion.preview}
                    </p>
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <div className="flex items-center gap-4">
                        <span>Posted by: {discussion.author}</span>
                        <span>•</span>
                        <span>{discussion.time}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <Menu>
                          <MenuButton className="flex items-center gap-1 hover:cursor-pointer">
                            <span>{discussion.replies} comments</span>
                            <ChevronDown size={20} />
                          </MenuButton>
                          <MenuItems
                            anchor="bottom end"
                            transition
                            className="bg-(--foreground) rounded-3xl p-2 flex flex-col gap-2 border-black border w-[25%] [--anchor-gap: 8px] origin-top transition duration-200 ease-out data-closed:scale-95 data-closed:opacity-0"
                          >
                            {discussion.recentComments.length === 0 ? (
                              <div className="block pl-2 rounded-2xl p-1">
                                No comments yet. Be the first to comment!
                              </div>
                            ) : (
                              <>
                                {discussion.recentComments.map(
                                  (recentComment, idx) => (
                                    <MenuItem
                                      key={idx}
                                      as="div"
                                      className="flex flex-col overflow-y-auto"
                                      onClick={(e: any) => e.preventDefault()}
                                    >
                                      <div className="block pl-2 rounded-2xl p-1">
                                        <span className="font-semibold">
                                          {recentComment.user}:
                                        </span>{" "}
                                        <span>
                                          {recentComment.comment_text}
                                        </span>
                                      </div>
                                    </MenuItem>
                                  )
                                )}
                              </>
                            )}
                            <div className="w-full h-fit flex flex-row items-center mt-2">
                              <input
                                type="text"
                                placeholder="Enter a message"
                                value={commentInputs[discussion.id] || ""}
                                onChange={(e) =>
                                  setCommentInputs((prev) => ({
                                    ...prev,
                                    [discussion.id]: e.target.value,
                                  }))
                                }
                                className="mr-2 ml-2 w-70"
                                onKeyDown={(e) => e.stopPropagation()}
                              />
                              <Button
                                onClick={(e) => {
                                  e.preventDefault();
                                  submitForumComment(
                                    discussion.id,
                                    commentInputs[discussion.id] || ""
                                  );
                                }}
                                className="bg-blue-400 text-black px-2 py-1 rounded-2xl hover:cursor-pointer hover:scale-105 hover:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out"
                              >
                                <Send size={18} />
                              </Button>
                            </div>
                          </MenuItems>
                        </Menu>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div
              className={`${
                showCreate ? "flex" : "hidden"
              } flex-col w-full h-full p-6`}
            >
              <Fieldset className="flex flex-col gap-4">
                <legend className="text-2xl font-bold mb-4">
                  Create New Discussion
                </legend>
                {forumError && (
                  <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                    <span className="block sm:inline">{forumError}</span>
                  </div>
                )}
                <Field className="mt-4">
                  <label
                    htmlFor="discussion_title"
                    className="block text-sm font-medium mb-2"
                  >
                    Discussion Title
                  </label>
                  <Input
                    id="discussion_title"
                    name="discussion_title"
                    type="text"
                    value={forumTitle}
                    onChange={(e) => setTitle(e.target.value)}
                    className={
                      "w-full bg-(--bg-section) border-2 border-gray-500 rounded-lg p-2 focus:border-blue-400 transition-colors"
                    }
                  />
                </Field>
                <Field className="mt-4">
                  <label
                    htmlFor="discussion_topic"
                    className="block text-sm font-medium mb-2"
                  >
                    Topic
                  </label>
                  <select
                    id="discussion_topic"
                    name="discussion_topic"
                    value={forumTag}
                    onChange={(e) => setForumTags(e.target.value)}
                    className="w-full bg-(--bg-section) rounded-lg p-2 border-2 border-gray-500 focus:border-blue-400 transition-colors"
                  >
                    <option value="STEM Research">STEM Research</option>
                    <option value="Project Ideas">Project Ideas</option>
                    <option value="Mentorship Tips">Mentorship Tips</option>
                    <option value="General Discussion">
                      General Discussion
                    </option>
                  </select>
                </Field>
                <Field className="mt-4">
                  <label
                    htmlFor="discussion_content"
                    className="block text-sm font-medium mb-2"
                  >
                    Content
                  </label>
                  <textarea
                    id="discussion_content"
                    name="discussion_content"
                    className="w-full bg-(--bg-section) rounded-lg p-2 border-2 border-gray-500 focus:border-blue-400 transition-colors"
                    rows={4}
                    value={forumDesc}
                    onChange={(e) => setForumDesc(e.target.value)}
                  ></textarea>
                </Field>
                <Field className="mt-4 flex flex-row justify-around w-[50%] self-center">
                  <Button
                    onClick={() => setShowCreate(false)}
                    className="mt-4 bg-red-400 text-black px-4 py-2 rounded-4xl hover:cursor-pointer hover:scale-105 hover:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => postForums()}
                    className="mt-4 bg-blue-400 text-black px-4 py-2 rounded-4xl hover:cursor-pointer hover:scale-105 hover:bg-(--highlighted) hover:text-white shadow-lg transition-[background-color,color,scale] duration-300 ease-in-out"
                  >
                    Post Discussion
                  </Button>
                </Field>
              </Fieldset>
            </div>
          </TabPanel>
        </TabPanels>
      </TabGroup>
    </div>
  );
}

export default Dashboard;
